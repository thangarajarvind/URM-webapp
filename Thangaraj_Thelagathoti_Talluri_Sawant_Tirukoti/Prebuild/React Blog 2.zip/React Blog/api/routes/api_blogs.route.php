<?php

    function wp_api_blogs_route(){

        register_rest_route(
            "api/v1", "/wp_api_create_blog",
            array(
                "methods" => "POST",
                "callback" => "wp_api_create_blog",
                "permission_callback" =>"__return_true"
            )
        );

        register_rest_route(
            "api/v1", "wp_api_list_blogs",
            array(
                "methods" => "GET",
                "callback" => "wp_api_list_blogs",
                "permission_callback" =>"__return_true"
            )
        );

        register_rest_route(
            "api/v1", "wp_api_get_blog/(?P<id>\d+)",
            array(
                "methods" => "GET",
                "callback" => "wp_api_get_blog",
                "permission_callback" =>"__return_true"
            )
        );

        register_rest_route(
            "api/v1", "wp_api_put_blog/(?P<id>\d+)",
            array(
                "methods" => "PUT",
                "callback" => "wp_api_put_blog",
                "permission_callback" =>"__return_true"
            )
        );

        register_rest_route(
            "api/v1", "wp_api_delete_blog/(?P<id>\d+)",
            array(
                "methods" => "DELETE",
                "callback" => "wp_api_delete_blog",
                "permission_callback" =>"__return_true"
            )
        );

    }
?>