<?php

    function wp_api_users_route(){

        register_rest_route(
            "api/v1", "/wp_api_create_user",
            array(
                "methods" => "POST",
                "callback" => "wp_api_create_user",
                "permission_callback" =>"__return_true"
            )
        );

        register_rest_route(
            "api/v1", "wp_api_login_user",
            array(
                "methods" => "POST",
                "callback" => "wp_api_login_user",
                "permission_callback" =>"__return_true"
            )
        );

    }
?>