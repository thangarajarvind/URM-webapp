<?php 
    /**
     * Plugin Name: Blog Backend API
     * Author: Meltus
     */

    register_activation_hook(__FILE__, 'wp_init_api_tables');

    function wp_init_api_tables(){

        global $wpdb;
        $api_user_table =$wpdb->prefix.'api_users';
        $api_blog_table =$wpdb->prefix.'api_blog_posts';

        $api_user_table_sql ="CREATE TABLE IF NOT EXISTS $api_user_table(
            id INT NOT NULL AUTO_INCREMENT,
            name VARCHAR(64) NOT NULL,
            email VARCHAR(32) NOT NULL,
            password VARCHAR(32) NOT NULL,
            time_joined TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
            PRIMARY KEY(id)
        );";

        $api_blog_table_sql ="CREATE TABLE IF NOT EXISTS $api_blog_table(
            id INT NOT NULL AUTO_INCREMENT,
            title VARCHAR(200) NOT NULL,
            thumbnail MEDIUMTEXT NOT NULL,
            body TEXT NOT NULL,
            author_id INT NOT NULL,
            time_published TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
            PRIMARY KEY(id),
            FOREIGN KEY (author_id) REFERENCES $api_user_table(id)
        );";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        dbDelta($api_user_table_sql);  // users table
        dbDelta($api_blog_table_sql); // blogs table
        $wpdb->show_errors();
    }
    // users route and service
    add_action("rest_api_init", "wp_api_users_route");
    require_once ABSPATH . "wp-content/plugins/api/routes/api_users.route.php";
    require_once ABSPATH . "wp-content/plugins/api/services/api_users.service.php";

    // blogs route and service
    add_action("rest_api_init", "wp_api_blogs_route");
    require_once ABSPATH . "wp-content/plugins/api/routes/api_blogs.route.php";
    require_once ABSPATH . "wp-content/plugins/api/services/api_blogs.service.php";
?>