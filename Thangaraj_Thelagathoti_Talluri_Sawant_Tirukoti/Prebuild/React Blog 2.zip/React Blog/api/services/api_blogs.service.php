<?php 
    function wp_api_create_blog($request){

        global $wpdb;
        $table_name =$wpdb->prefix.'api_blog_posts';
        $data =$request->get_json_params();
        $rows =$wpdb->insert(
            $table_name,
            array(
                'title' => $data['title'],
                'thumbnail' => $data['thumbnail'],
                'body' => $data['body'],
                'author_id' => $data['author_id']
            )
        );
        return $wpdb->last_error;
    }

    function wp_api_list_blogs(){
        global $wpdb;
        $table_name =$wpdb->prefix.'api_blog_posts';
        $result =$wpdb->get_results("SELECT * FROM $table_name;");

        return $result;
    }
    
    function wp_api_get_blog($request){
        global $wpdb;
        $id =$request['id'];
        $table_name =$wpdb->prefix.'api_blog_posts';
        $result =$wpdb->get_results("SELECT * FROM $table_name WHERE id =$id");
        if(!empty($result)) return $result[0];
        return array(
            "status" => 404,
            "message" => "Blog Not found"
        );
    }

    function wp_api_put_blog($request){
        global $wpdb;
        $id =$request['id'];
        $table_name =$wpdb->prefix.'api_blog_posts';
        $data =$request->get_json_params();
        $result =$wpdb->get_results("SELECT * FROM $table_name WHERE id =$id");

        return $result;
    }

    function wp_api_delete_blog($request){
        global $wpdb;
        $id =$request['id'];
        $table_name =$wpdb->prefix.'api_blog_posts';
        $result =$wpdb->get_results("DELETE FROM $table_name WHERE id =$id");

        return $result;
    }
?>