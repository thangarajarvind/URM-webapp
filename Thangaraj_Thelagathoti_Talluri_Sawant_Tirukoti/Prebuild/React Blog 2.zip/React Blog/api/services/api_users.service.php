<?php 
    function wp_api_create_user($request){

        global $wpdb;
        $table_name =$wpdb->prefix.'api_users';
        $data =$request->get_json_params();

        $rows =$wpdb->insert(
            $table_name,
            array(
                'name' => $data['name'],
                'email' => $data['email'],
                'password' => $data['password']
            )
        );
        return $rows;
    }

    function wp_api_login_user($request){
        global $wpdb;
        $data =$request->get_json_params();
        $query = $wpdb->prepare("SELECT id FROM {$wpdb->prefix}api_users WHERE email = %s AND password = %s", $data['username'], $data['password']);
        $result = $wpdb->get_results($query);
        if(!empty($result) >0) return $result[0];
        return array(
            'status' => 401,
            'message' => 'User with password found not found'
        );
    }
?>