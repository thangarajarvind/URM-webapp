import {createBrowserRouter, RouterProvider} from 'react-router-dom';
import {HomePage, LoginPage, LogoutPage, PostFactory, RegisterPage, SinglePost} from './pages';
import './assets/css/app.css';
const App =() =>{
  const router =createBrowserRouter([
    {path: '/', index: true, element: <HomePage />},
    {path: '/login', element: <LoginPage />},
    {path: '/logout', element: <LogoutPage />},
    {path: '/register', element: <RegisterPage />},
    {path: '/new_post', element: <PostFactory />},
    {path: '/edit_post/:id', element: <PostFactory />},
    {path: '/view_post/:id', element: <SinglePost />}
  ]);

  return (
    <main>
      <RouterProvider router={router}/>
    </main>
  );
}

export default App;
