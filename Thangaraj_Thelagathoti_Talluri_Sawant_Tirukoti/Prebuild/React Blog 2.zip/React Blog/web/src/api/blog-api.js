import api from ".";
import {blog_posts} from './data'

export const fetch_blog_posts =async () =>{
    const response =await api.get('/wp_api_list_blogs');
    return response.data;
}

export const fetch_blog_post =async id =>{
    const response =await api.get(`/wp_api_get_blog/${id}`);
    return response.data;
}

export const create_blog_post =async data =>{
    const response =await api.post('/wp_api_create_blog', data);
    return response.data;
}

export const edit_blog_post =async (id, new_data) =>{
    const response =await api.put(`/edit_api_blog_post${id}`, new_data);
    return response.data;
}

export const remove_blog_post =async id =>{
    const response =await api.delete(`/remove_api_blog_post/${id}`);
    return response.data;
}