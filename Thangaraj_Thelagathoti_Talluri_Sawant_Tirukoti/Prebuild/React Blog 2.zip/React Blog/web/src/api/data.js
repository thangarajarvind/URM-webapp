export const blog_posts =[
    {
        id: 1,
        title: 'Pregnancy Loss',
        body: 'It can be difficult to know what to say to someone who has just lost a baby. Here are a few thoughts from those of us who have experienced pregnancy or infant loss, as well as a comforting prayer for miscarriage to all those affected.',
        thumbnail: 'https://newbreak.church/wp-content/uploads/2023/04/ymtdjv7jkpi-1024x683.jpg',
        author: 'Netcom',
        date_published: '30-07-2023'
    },
    {
        id: 2,
        title: 'You Are Not Just Talented, You Are Spiritually Gifted',
        body: 'And I am not that special for saying that. Most of us want to leave an imprint on the world that makes it better. Sure, maybe our ambitions are vastly different. Some of us dream of influencing the WHOLE world while some of us see OUR world as the people we aim to influence. Nevertheless, all of us want to make a good difference. And that’s a good thing! God wants that for us too.',
        thumbnail: 'https://newbreak.church/wp-content/uploads/2023/02/3kv48ns4wuu-1024x683.jpg',
        author: 'Netcom',
        date_published: '29-07-2023'
    },
    {
        id: 3,
        title: 'A Lesson in Reading the “Commands” of Scripture',
        body: 'The more you study Scripture, the more you see how important context is for understanding the meaning of a passage. This is especially important when it comes to seeing how the “commands” of Scripture fit with the truths that ground them. Or to say it another way',
        thumbnail: 'https://newbreak.church/wp-content/uploads/2023/02/xqxjjhk-c08-1024x683.jpg',
        author: 'Netcom',
        date_published: '28-07-2023'
    },
    {
        id: 4,
        title: 'You Were Loved Into Existence',
        body: `The beginning of the year is often a time of deep reflection. Our hope is that your thoughts are not only directed toward your resolutions but also about more profound existential questions. We will help you get there: our first two months of sermons are entirely directed toward the subject of purpose!
        I’ve been part of many dialogues between Christians and Atheists, which often circle around whether everything (including humanity) was intelligently created. In essence, does humanity have a God-given purpose? Or are we merely an accident of the universe’s own chaotic doing? The question, however, has far-reaching implications, especially when it comes to love.`,
        thumbnail: 'https://newbreak.church/wp-content/uploads/2023/01/abkeaojny0s-1024x683.jpg',
        author: 'Netcom',
        date_published: '27-07-2023'
    },
    {
        id: 5,
        title: 'Bible Verses to Ground Your Day in Gratitude',
        body: `It’s the opening line of a book I have been reading to my son in this season of life. And it has me thinking: Do I wake up “with a very thankful heart?” Or is this another one of those times as a parent where the books we hope to influence our children do not seem to pierce our callous heart? I’ll admit, this is a bit melodramatic. One of my family values is “gratitude.” I am passionate about the power of gratitude from both a biblical and psychological perspective. At my best gratitude is even part of my daily liturgy and routine. However, that’s not every day. So here I am, back to reading that line with my son and I feel a sense of resolve to create a resource for myself to come back to.`,
        thumbnail: 'https://newbreak.church/wp-content/uploads/2022/11/p2oqw69vxp4-1024x636.jpg',
        author: 'Netcom',
        date_published: '26-07-2023'
    },
]