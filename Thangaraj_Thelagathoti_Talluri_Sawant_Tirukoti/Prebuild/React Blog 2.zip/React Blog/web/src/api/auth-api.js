import api from ".";

export const login_user =async data =>{
    const response =await api.post('/wp_api_login_user', data);
    return response.data;
}

export const register_user =async data =>{
    const response =await api.post('/wp_api_create_user', data);
    return response.data;
}