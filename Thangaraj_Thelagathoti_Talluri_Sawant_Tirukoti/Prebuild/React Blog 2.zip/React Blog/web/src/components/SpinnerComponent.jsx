import React from 'react'

const SpinnerComponent = ({message}) => {
  return (
    <div className='spinner-container'>
        <div className="spinner"></div>
        <p>{message || 'Please Wait...'}</p>
    </div>
  )
}

export default SpinnerComponent;