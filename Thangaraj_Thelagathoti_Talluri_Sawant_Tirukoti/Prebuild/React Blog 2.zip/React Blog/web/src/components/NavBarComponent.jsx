import { useEffect, useState } from "react";
import { NavLink } from "react-router-dom";

const NavBarComponent = () => {
  const [isLoggedIn, setIsLoggedIn] =useState(false);
  const links =[
    {path: '/', label: 'Posts'},
    ...isLoggedIn? [{path: '/new_post', label: 'New Post'}, {path: '/logout', label: 'Logout'}] :[{path: '/login', label: 'Login'}, {path: '/register', label: 'Register'}]
  ];

  useEffect(() =>{
    const session =JSON.parse(localStorage.getItem('session')) || {};
    const {isLoggedIn} =session;
    setIsLoggedIn(isLoggedIn);
    return () =>{
      setIsLoggedIn(false);
    }
  }, []);
  return (
    <nav className="navigation">
      <h2 className="title">React Blog</h2>
      <ul className="nav-links">
        {links.map(({path, label}, index) =>(<li key={index}><NavLink to={path}>{label}</NavLink></li>))}

      </ul>
    </nav>
  )
}

export default NavBarComponent;