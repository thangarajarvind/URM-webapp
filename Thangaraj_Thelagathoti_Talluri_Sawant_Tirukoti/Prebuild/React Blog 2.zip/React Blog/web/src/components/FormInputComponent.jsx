import React from 'react'

const FormInputComponent = ({type ='text', name, label, placeholder ='', register, errors ={}, style ={}, accept}) => {
  return (
    <div className='input-group' style={style}>
        {label &&<label htmlFor={name}>{label}</label>}
        {type=='textarea'? <textarea rows={7} placeholder={placeholder} {...register} className={`${errors[name] && 'error-field'}`}></textarea>:<input type={type} placeholder={placeholder} {...register}  accept={accept} className={`${errors[name] && 'error-field'}`}/>}
        {errors[name] &&<small id={`err-${name}`} className='error-label'>{errors[name].message? errors[name].message: ''}</small>}
    </div>
  )
}

export default FormInputComponent;