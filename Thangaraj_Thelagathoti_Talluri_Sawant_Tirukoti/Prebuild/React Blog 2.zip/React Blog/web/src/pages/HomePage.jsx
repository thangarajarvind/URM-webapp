import { useState, useEffect } from 'react';
import {fetch_blog_posts} from '../api/blog-api';
import { NavLink } from 'react-router-dom';
import blog_bg from '../assets/img/blog-bg.jpg';
import {NavBarComponent, SpinnerComponent} from '../components'

const HomePage = () => {
  const [blogPosts, setBlogPosts] =useState([]);
  const [loading, setLoading] =useState(false);
  const months =['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
  useEffect(() =>{
    setLoading(true);
    fetch_blog_posts().then(data =>{
      setBlogPosts(data);
      setLoading(false);
    }).catch(error =>{
      console.error(error);
      setLoading(false);
    });
    return () =>{
      setBlogPosts([]);
    }
  }, []);
  return (
    <>
      <NavBarComponent />
      <div className='container'>
        <section>
          <img src={blog_bg} />
          <h2>React Blogs</h2>
        </section>
        <div className="content">
        
        {
          loading?<div style={{width: '50%', margin: '4rem auto', display: 'flex', justifyContent: 'center'}}><SpinnerComponent message={'Loading ...'}/></div>:(
            blogPosts.length? blogPosts.map(({id, title, time_published, thumbnail, body}, index) =>(<div className='card' key={index}>
              <img src={thumbnail} />
              <div className="card-body">
                <h4>{`${title.slice(0, 10)}`}</h4>
                <p>{`${body.slice(0, 20)}`}</p>
                <p>{`${months[new Date(time_published).getMonth()]}, ${new Date(time_published).getDate()} ${new Date(time_published).getFullYear()}`}</p>
                <NavLink to={`/view_post/${id}`} className='button-link'>Read</NavLink>
              </div>
            </div>)): <div style={{width: '50%', border: '1px solid rgba(0,0,0,.4)', borderRadius: '.3rem', padding: '1rem', textAlign: 'center', margin: '4rem auto'}}>No Blogs Yet!</div>
          )
        }
        </div>
      </div>
    </>
  )
}

export default HomePage;