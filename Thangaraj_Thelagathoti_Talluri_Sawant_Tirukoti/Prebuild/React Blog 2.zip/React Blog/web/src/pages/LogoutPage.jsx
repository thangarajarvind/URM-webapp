import {useEffect} from 'react';;
import { SpinnerComponent } from '../components';
import { useNavigate } from 'react-router-dom';

const LogoutPage = () => {
    const navigate =useNavigate();
    useEffect(() =>{
        localStorage.removeItem('session');
        navigate('/login', {replace: true});
    }, []);
    return (
        <div style={{height: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center'}}><SpinnerComponent/></div>
    )
}

export default LogoutPage;