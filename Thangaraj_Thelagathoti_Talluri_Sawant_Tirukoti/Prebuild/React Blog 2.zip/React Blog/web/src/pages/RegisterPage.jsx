import {useState, useEffect} from 'react';
import { FormInputComponent, NavBarComponent, SpinnerComponent } from '../components';
import {useForm} from 'react-hook-form';
import {register_user} from '../api/auth-api';
import { useNavigate } from 'react-router-dom';

const RegisterPage = () => {
  const navigate =useNavigate();
  useEffect(() =>{
    const session =JSON.parse(localStorage.getItem('session')) || {};
    const {isLoggedIn} =session;
    if(isLoggedIn) navigate('/', {replace: true});
  }, []);
  const {register, formState: {errors}, reset, handleSubmit} =useForm();
  const [isSubmitting, setIsSubmitting] =useState(false);
  const [serverError, setServerError] =useState(null);
  const inputFields =[
    {name: 'name', label: 'Name*', placeholder: 'Enter your first and last name', validations: {
      required: 'Name is required*',
    }},
    {type: 'email', name: 'email', label: 'Email*', placeholder: 'Enter your email address', validations: {
      required: 'Email is required*',
    }},
    {type: 'password', name: 'password', label: 'Password*', placeholder: 'Enter Password', validations: {
      required: 'Login Password must be provided*',
    }},
    {type: 'password', name: 'cpassword', label: 'Confirm Password*', placeholder: 'Enter Password Again', validations: {
      required: 'Please confirm your password*',
    }},
  ];

  const handleRegister =async data =>{
    const form =document.forms['login-form'];
    if(form) [...form.querySelectorAll('input, button')].forEach(field =>field.disabled =true);
    setIsSubmitting(true);
    setServerError(null);
    try {
      const response =await register_user(data);
      reset();
      navigate('/login', {replace: true});
    } catch ({response: {data:{message}}}) {
      setServerError(message);
    }
    if(form) [...form.querySelectorAll('input, button')].forEach(field =>field.disabled =false);
    setIsSubmitting(false);
  }
  return (
    <>
      <NavBarComponent />
      <div className="form-container">
        <form action="" name='login-form' onSubmit={handleSubmit(handleRegister)} style={{padding: "1rem 2rem"}}>
          <h3 style={{padding: '0'}}>Create Account</h3>
          {inputFields.map(({type, name, label, placeholder, validations}, index) =><FormInputComponent type={type} name={name} label={label} placeholder={placeholder} key={index} errors={errors} register={register(name, validations)}/>)}
          {isSubmitting? <SpinnerComponent />:<button type='submit' className='form-submit-cta'>Register</button>}
          {serverError && <small className='error-alert'>{serverError}</small>}
        </form>
      </div>
    </>
  )
}

export default RegisterPage;