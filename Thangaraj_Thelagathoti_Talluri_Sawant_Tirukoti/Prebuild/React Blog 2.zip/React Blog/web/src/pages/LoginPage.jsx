import {useState, useEffect} from 'react'
import { FormInputComponent, NavBarComponent, SpinnerComponent } from '../components';
import {useForm} from 'react-hook-form';
import {login_user} from '../api/auth-api';
import { useNavigate } from 'react-router-dom';

const LoginPage = () => {
  const navigate =useNavigate();
  useEffect(() =>{
    const session =JSON.parse(localStorage.getItem('session')) || {};
    const {isLoggedIn} =session;
    if(isLoggedIn) navigate('/', {replace: true});
  }, []);
  const {register, formState: {errors}, reset, handleSubmit} =useForm();
  const [isSubmitting, setIsSubmitting] =useState(false);
  const [serverError, setServerError] =useState(null);
  const inputFields =[
    {name: 'username', label: 'Email*', placeholder: 'Enter Email', validations: {
      required: 'Login ID must be provided',
    }},
    {type: 'password', name: 'password', label: 'Password*', placeholder: 'Enter Password', validations: {
      required: 'Login Password must be provided',
    }},
  ];

  const handleLogin =async data =>{
    const form =document.forms['login-form'];
    if(form) [...form.querySelectorAll('input, button')].forEach(field =>field.disabled =true);
    setIsSubmitting(true);
    setServerError(null);
    try {
      const response =await login_user(data);
      const {id, message} =response;
      if(message) setServerError(message);
      else{
        localStorage.setItem('session', JSON.stringify({id, isLoggedIn: true}));
        reset();
        navigate('/', {replace: true});
      }
    } catch ({response: {data:{message}}}) {
      setServerError(message);
    }
    if(form) [...form.querySelectorAll('input, button')].forEach(field =>field.disabled =false);
    setIsSubmitting(false);
  }
  
  return (
    <>
      <NavBarComponent />
      <div className="form-container">
        <form action="" name='login-form' onSubmit={handleSubmit(handleLogin)}>
          <h3>Please Login</h3>
          {inputFields.map(({type, name, label, placeholder, validations}, index) =><FormInputComponent type={type} name={name} label={label} placeholder={placeholder} key={index} errors={errors} register={register(name, validations)}/>)}
          {isSubmitting? <SpinnerComponent />:<button type='submit' className='form-submit-cta'>Login</button>}
          {serverError && <small className='error-alert'>{serverError}</small>}
        </form>
      </div>
    </>
  )
}

export default LoginPage;