export {default as HomePage} from './HomePage';
export {default as LoginPage} from './LoginPage';
export {default as LogoutPage} from './LogoutPage';
export {default as SinglePost} from './SinglePost';
export {default as PostFactory} from './PostFactory';
export {default as RegisterPage} from './RegisterPage';