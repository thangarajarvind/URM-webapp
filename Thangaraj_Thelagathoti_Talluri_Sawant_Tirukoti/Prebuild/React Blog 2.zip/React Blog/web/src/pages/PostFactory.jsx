import {useEffect, useState} from 'react';
import { useNavigate } from 'react-router-dom';
import {useForm} from 'react-hook-form';
import { FormInputComponent, NavBarComponent, SpinnerComponent } from '../components';
import {create_blog_post} from '../api/blog-api';

const PostFactory = () => {
  const navigate =useNavigate();
  const {register, formState: {errors}, reset, handleSubmit} =useForm();
  const [isSubmitting, setIsSubmitting] =useState(false);
  const [serverError, setServerError] =useState(null);
  useEffect(() =>{
    const session =JSON.parse(localStorage.getItem('session')) || {};
    const {isLoggedIn} =session;
    if(!isLoggedIn) navigate('/login', {replace: true});
  }, []);
  const handlePublish =data =>{
    const form =document.forms['blog-form'];
    const {title, body} =data;
    if(form) [...form.querySelectorAll('input, button, textarea')].forEach(field =>field.disabled =true);
    setIsSubmitting(true);
    setServerError(null);
    const {thumbnail} =form;
    const file =thumbnail.files[0];
    const reader =new FileReader();
    reader.onloadend =async () =>{
      try {
        const session =JSON.parse(localStorage.getItem('session')) || {};
        const {id} =session;
        const blogData ={title, thumbnail: reader.result, body, author_id: id};
        const response =await create_blog_post(blogData);
        console.log(response);
        setIsSubmitting(false);
        reset();
      } catch (error) {
        if(error.message) setServerError(error.message);
        console.log(error);
      }
    if(form) [...form.querySelectorAll('input, button, textarea')].forEach(field =>field.disabled =false);
  }
  reader.readAsDataURL(file);

  }
  const inputFields =[
    {name: 'title', label: 'Title', placeholder: 'Enter title', validations: {
      required: 'Title is required*',
    }},
    {type: 'file', name: 'thumbnail', label: 'Thumbnail', placeholder: 'Upload Thumbnail', accept: 'image/*', validations: {
      required: 'Thumbnail is required*',
    }},
    {type: 'textarea', name: 'body', label: 'Body', placeholder: 'Post Content', validations: {
      required: 'Blog post body is required*',
    }},
  ]
  return (
    <>
      <NavBarComponent />
      <div className='factory' >
        <form onSubmit={handleSubmit(handlePublish)} name='blog-form'>
          <h1>Create New Blog</h1>
          {inputFields.map(({type, name, label, placeholder, validations, accept}, index) =><FormInputComponent type={type} name={name} label={label} placeholder={placeholder} key={index} errors={errors} register={register(name, validations)} style ={{marginBottom: '2.5rem'}} accept ={accept}/>)}
          {isSubmitting? <SpinnerComponent />:<button type='submit' className='form-submit-cta'>Publish</button>}
          {serverError && <small className='error-alert'>{serverError}</small>}
        </form>
      </div>
    </>
  )
}

export default PostFactory;